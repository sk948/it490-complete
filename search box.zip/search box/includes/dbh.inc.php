<?php

$dbServer = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "yourdbname";

$conn = mysqli_connect($dbServer, $dbUsername, $dbPassword, $dbName);
